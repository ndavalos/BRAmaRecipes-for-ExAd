/*
Antihack & AdminTools - Christian Lorenzen - www.infiSTAR.de
#1709
*/
